AXIS CONNECT - Student Community of Axis Institute of Higher Education (BCA project)

OBJECTIVE: A basic frontend demo of a student marketplace and community.
TECHNOLOGIES: HTML, CSS, JavaScript only. No backend, no internet needed.

HOW TO START
1. Extract the Axis-Connect folder.
2. Open the folder.
3. Double-click index.html.
4. Use the menu on the left (top on phones).

FILES
index.html         all pages (sections); JavaScript shows one at a time
assets/css/        style.css, responsive.css
assets/js/         app.js (page switching), marketplace.js, community.js
assets/images/     local SVG pictures

FEATURES: marketplace (search, category filter, price sort, save, details, add listing),
student search, demo chat, campus map, events, clubs (join/leave).

LIMITATIONS
- Everything is sample data. Nothing is saved: refresh resets the page.
- Chat is not real; real chat, login and payments need a backend and database.
- The map is a sample layout, not the real campus.

CHANGING CONTENT: edit the arrays at the top of marketplace.js and community.js.
