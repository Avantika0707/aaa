// app.js - shows one section (page) at a time
function showPage(name){
  var pages = document.getElementsByClassName('page');
  for (var i = 0; i < pages.length; i++){
    pages[i].style.display = 'none';   // hide every page
  }
  document.getElementById(name).style.display = 'block'; // show the chosen page
}
showPage('home');
