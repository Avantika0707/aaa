// community.js - students, chat, map, events, clubs
var students = [
  {name:"Aarav Sharma", id:"AX-1001", dept:"BCA", status:"Current Student"},
  {name:"Meera Kapoor", id:"AX-1002", dept:"BBA", status:"Current Student"},
  {name:"Rohan Patel", id:"AX-1003", dept:"MBBS", status:"Current Student"},
  {name:"Sneha Das", id:"AX-1004", dept:"BTech", status:"Current Student"},
  {name:"Kabir Mehta", id:"AX-1005", dept:"BPharma", status:"Alumni"},
  {name:"Ishita Rao", id:"AX-1006", dept:"Law", status:"Current Student"},
  {name:"Dev Arora", id:"AX-1007", dept:"MBA", status:"Alumni"},
  {name:"Pooja Nair", id:"AX-1008", dept:"BCA", status:"Alumni"}
];
var clubs = ["Coding Club","AI and Robotics Club","Cybersecurity Club","Entrepreneurship Club","Debate Club","Cultural and Dance Club","Music Club","Photography Club","Sports Club","Social Service Club"];
var joined = [];
var events = [
  {title:"Demo Hackathon", date:"20 Nov 2026", venue:"Computer Lab 1"},
  {title:"Cyber Safety Workshop", date:"5 Nov 2026", venue:"Seminar Hall"},
  {title:"Cultural Fest", date:"2 Dec 2026", venue:"Auditorium"},
  {title:"Alumni Meetup", date:"15 Dec 2026", venue:"Canteen Lawn"}
];
var places = [
  {name:"Main Gate", info:"Entry point with a security desk."},
  {name:"Library", info:"Books and quiet study (Block D)."},
  {name:"Computer Labs", info:"Programming labs (Block C)."},
  {name:"Auditorium", info:"Events and seminars (Block E)."},
  {name:"Canteen", info:"Food court. A safe public place to meet."}
];
var chats = {};   // messages for each student, kept only while the page is open

// ----- Students -----
function showStudents(){
  var text = document.getElementById('studentSearch').value.toLowerCase();
  var html = '';
  for (var i = 0; i < students.length; i++){
    var s = students[i];
    if (s.name.toLowerCase().indexOf(text) !== -1 || s.id.toLowerCase().indexOf(text) !== -1){
      html += '<div class="card"><img src="assets/images/student-avatars/avatar' + (i % 4 + 1) + '.svg" alt="" width="50">' +
        '<h3>' + s.name + '</h3><p>' + s.id + ' | ' + s.dept + '</p><p>' + s.status + '</p>' +
        '<button onclick="openChat(' + i + ')">Open Chat</button></div>';
    }
  }
  if (html === ''){ html = '<p>No students found.</p>'; }
  document.getElementById('studentList').innerHTML = html;
}

// ----- Chat -----
function fillChatList(){
  var html = '';
  for (var i = 0; i < students.length; i++){
    html += '<option value="' + i + '">' + students[i].name + '</option>';
  }
  document.getElementById('chatWith').innerHTML = html;
  chats[0] = [{me:false, text:"Hi! Are you joining the coding club?"}];
}
function showMessages(){
  var who = document.getElementById('chatWith').value;
  var list = chats[who] || [];
  var html = '';
  for (var i = 0; i < list.length; i++){
    html += '<p class="' + (list[i].me ? 'me' : '') + '">' + (list[i].me ? 'You: ' : 'Them: ') + list[i].text + '</p>';
  }
  if (html === ''){ html = '<p>No messages yet.</p>'; }
  document.getElementById('messages').innerHTML = html;
}
function openChat(index){
  showPage('chat');
  document.getElementById('chatWith').value = index;
  showMessages();
}
function sendMessage(){
  var input = document.getElementById('messageInput');
  var who = document.getElementById('chatWith').value;
  if (input.value.trim() === ''){ alert('Type a message first.'); return; }
  if (!chats[who]){ chats[who] = []; }
  chats[who].push({me:true, text:input.value});
  input.value = '';
  showMessages();
}
// Press Enter to send
document.getElementById('messageInput').onkeydown = function(e){
  if (e.key === 'Enter'){ sendMessage(); }
};

// ----- Campus map -----
function showLocation(i){
  document.getElementById('locInfo').innerHTML = '<h3>' + places[i].name + '</h3><p>' + places[i].info + '</p>';
}
function fillPlaces(){
  var html = '';
  for (var i = 0; i < places.length; i++){ html += '<option value="' + i + '">' + places[i].name + '</option>'; }
  document.getElementById('locSelect').innerHTML = html;
}

// ----- Events -----
function showEvents(){
  var html = '';
  for (var i = 0; i < events.length; i++){
    html += '<div class="card"><img src="assets/images/events/event.svg" alt=""><h3>' + events[i].title + '</h3>' +
      '<p>' + events[i].date + ' | ' + events[i].venue + '</p>' +
      '<button onclick="registerEvent(' + i + ')">Register Interest</button></div>';
  }
  document.getElementById('eventList').innerHTML = html;
}
function registerEvent(i){
  alert('Interest registered for ' + events[i].title + ' (simulated, nothing is sent).');
}

// ----- Clubs -----
function showClubs(){
  var html = '';
  for (var i = 0; i < clubs.length; i++){
    var isJoined = joined.indexOf(i) !== -1;
    html += '<div class="card"><img src="assets/images/clubs/club.svg" alt="" width="50"><h3>' + clubs[i] + '</h3>' +
      '<p>Coordinator: sample faculty (fictional)</p>' +
      '<button onclick="toggleClub(' + i + ')">' + (isJoined ? 'Joined (click to leave)' : 'Join Club') + '</button></div>';
  }
  document.getElementById('clubList').innerHTML = html;
  document.getElementById('joinCount').innerHTML = joined.length;
}
function toggleClub(i){
  var pos = joined.indexOf(i);
  if (pos === -1){ joined.push(i); alert('You joined ' + clubs[i] + ' (simulated).'); }
  else if (confirm('Leave ' + clubs[i] + '?')){ joined.splice(pos, 1); }
  showClubs();
}

showStudents(); fillChatList(); showMessages(); fillPlaces(); showEvents(); showClubs();
